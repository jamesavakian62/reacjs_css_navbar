import Navbar from "./Navbar"
import Pricing from "./pages/Pricing"
import Home from "./pages/Home"

import Portfolio from "./pages/Portfolio"
import Services from "./pages/Services"
import Contact from "./pages/Contact"
import AboutMe from "./pages/AboutMe"

import { Route, Routes } from "react-router-dom"

function App() {
  return (
    <>
      <Navbar />
      <div className="container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/pricing" element={<Pricing />} />
        


          <Route path="/portfolio" element={<Portfolio />} />
          <Route path="/services" element={<Services />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/aboutme" element={<AboutMe />} />

        </Routes>
      </div>
    </>
  )
}

export default App
